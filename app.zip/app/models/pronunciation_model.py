
class Pronunciation:
    def __init__(self, id, lexeme_id, pronunciation_url, variety=None):
        self.id = id
        self.lexeme_id = lexeme_id
        self.pronunciation_url = pronunciation_url
        self.variety = variety


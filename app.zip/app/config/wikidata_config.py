
WIKIDATA_API_URL = 'https://www.wikidata.org/w/api.php'


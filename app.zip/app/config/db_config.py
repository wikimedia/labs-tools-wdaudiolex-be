
class Config:
    SQLALCHEMY_DATABASE_URI = 'sqlite:///app.db'  # Change this to your database URI
    SQLALCHEMY_TRACK_MODIFICATIONS = False


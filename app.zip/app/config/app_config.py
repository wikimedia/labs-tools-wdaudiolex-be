
class Config:
    DEBUG = True
    SECRET_KEY = 'your_secret_key'  # Change this to a secure key



def sanitize_pattern(pattern):
    # Remove punctuation and make pattern case insensitive
    return pattern.strip().lower()

